#include "stdafx.h"
#include "VSolver.h"


CVSolver::CVSolver(void)
{
}


CVSolver::~CVSolver(void)
{
}

cv::Mat CVSolver::GetQ( int dim )
{
	time_t t=time(0);
	std::srand((unsigned)(t));
	cv::Mat rMat(dim,1,CV_64F);
	for (int i=0;i<dim;++i)
	{
		rMat.at<double>(i,0)=std::rand()%40-20;
	}
	return rMat*rMat.t(); 
}

double CVSolver::f( cv::Mat startIndex,cv::Mat Q,cv::Mat b )
{
	cv::Mat x(startIndex);
	return ((x.t()*Q).t()).dot(x)*0.5+b.dot(x);
}

cv::Mat CVSolver::Getb( int dim )
{
	std::srand(100);
	cv::Mat rMat(dim,1,CV_64F);
	for (int i=0;i<dim;++i)
	{
		rMat.at<double>(i,0)=std::rand()%20;
	}
	return rMat;
}

double CVSolver::ComputeConst( cv::Mat x,cv::Mat Q,cv::Mat b )
{
	cv::Mat x1(x),x2,d;
	double f1=0,f2=0;
	int tag=0;
	for (int i=0;i<100;++i)
	{
		x2.release();

		d=Getd(x1,Q,b);
		double md=d.dot(d);
		x2=x1+(d/pow(md,0.5));
		f1=f(x1,Q,b);
		f2=f(x2,Q,b);

		std::cout<<"****************"<<std::endl;
		std::cout<<"����:"<<i<<'\n'<<f1<<'\n'<<f2<<'\n';
		if (abs(f1-f2)<0.2)
		{
			break;
		}
		else
		{
			x1.release();
			x1=x2;
		}
		tag=i;
	}
	std::cout<<tag<<std::endl;
	return f2;
}

cv::Mat CVSolver::Getd( cv::Mat x,cv::Mat Q,cv::Mat b )
{
	return -1*(Q*x+b);
}

double CVSolver::ComputeVar( cv::Mat x,cv::Mat Q,cv::Mat b )
{
	cv::Mat x1(x),x2,d;
	double f1=0.0,f2=0.0;

	for (int i=0;i<2000;++i)
	{
		x2.release();
		x2=GetPointAmj(x1,Q,b);
		d=Getd(x1,Q,b);
		f1=f(x1,Q,b);
		f2=f(x2,Q,b);

		std::cout<<"****************"<<std::endl;
		std::cout<<"����:"<<i<<'\n'<<f1<<'\n'<<f2<<'\n';

		if (d.dot(d)<0.09)
		{
			break;
		}
		else
		{
			x1.release();
			x1=x2;
		}

	}
	std::cout<<"x1="<<x1<<std::endl;
	std::cout<<"f1="<<f(x1,Q,b)<<std::endl;
	return f1;
}

cv::Mat CVSolver::GetPointAmj( cv::Mat x,cv::Mat Q,cv::Mat b,double sigma,double beta )
{
	double s=1;
	double m=0.0;
	double tag=0.0;

	cv::Mat x1(x),x2;
	cv::Mat d=Getd(x,Q,b);
	double md=d.dot(d);
	do 
	{
		x2.release();
		x2=x1+s*pow(beta,m)*d;
		tag=f(x1,Q,b)-f(x2,Q,b)-sigma*s*pow(beta,m)*md;
		++m;
	} while (tag<0);
	std::cout<<"m="<<m<<std::endl;
	return x2;
}
